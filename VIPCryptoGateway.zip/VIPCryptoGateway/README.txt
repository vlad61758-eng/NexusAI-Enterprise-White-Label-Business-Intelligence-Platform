VIP Crypto Gateway Bot Source Code\n\nRun 'python bot.py' to start.
