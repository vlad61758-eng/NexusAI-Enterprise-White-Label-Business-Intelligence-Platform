import ccxt\n\nprint('Crypto Gateway started!')
