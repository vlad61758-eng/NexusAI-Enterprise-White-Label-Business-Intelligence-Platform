Smart Funnel Bot Source Code\n\nRun 'python main.py' to start.
