import aiogram\n\nprint('Smart Funnel Bot started!')
