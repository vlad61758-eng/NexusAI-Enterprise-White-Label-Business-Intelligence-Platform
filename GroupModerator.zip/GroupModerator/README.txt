Group Moderator Bot Source Code\n\nRun 'python bot.py' to start.
