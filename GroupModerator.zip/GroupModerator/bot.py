import pyrogram\n\nprint('Group Moderator started!')
