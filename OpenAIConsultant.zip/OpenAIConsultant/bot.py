import openai\n\nprint('OpenAI Consultant started!')
