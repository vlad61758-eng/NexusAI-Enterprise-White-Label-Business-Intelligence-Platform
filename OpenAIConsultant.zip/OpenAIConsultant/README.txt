OpenAI Consultant Bot Source Code\n\nRun 'python bot.py' to start.
